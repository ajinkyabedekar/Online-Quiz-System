package Model;

import java.sql.*;

public class DatabaseHelper {
	Connection con=null;

	public DatabaseHelper() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/quiz";
			String user = "root";
			String pass = "Bahu@123";
			Connection con = DriverManager.getConnection(url, user, pass);
			this.con = con;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public Connection getConnection() {
		return con;
	}

	public void closeConnection() {
		try {
			con.close();
			System.out.println("DatabaseHelper connection closed"+con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}